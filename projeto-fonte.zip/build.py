#!/usr/bin/env python3
"""Monta o index.html final (arquivo único) a partir de src/ e fonts/.
Uso:  python3 build.py      ->  gera ./index.html"""
import base64, pathlib
root = pathlib.Path(__file__).parent
read = lambda p: (root / p).read_text(encoding="utf-8")
font = base64.b64encode((root / "fonts/Cronicas.ttf").read_bytes()).decode()
html = read("src/index.template.html")
html = html.replace("__STYLES__", read("src/styles.css").replace("__FONT_BASE64__", font))
html = html.replace("__SCRIPT__", read("src/app.js"))
(root / "index.html").write_text(html, encoding="utf-8")
print("index.html gerado:", len(html), "bytes")
