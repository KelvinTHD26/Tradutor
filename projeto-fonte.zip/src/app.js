/* =====================================================================
   Crônicas do Vazio Atômico — tradutor do alfabeto
   ---------------------------------------------------------------------
   A cifra: cada palavra tem as letras invertidas (a ordem das palavras
   fica) e cada letra vira um símbolo da fonte Cronicas, guardado como
   caractere da área privada do Unicode (U+E000 = A ... U+E019 = Z).
   Sem maiúsculas/minúsculas, sem números e sem acentos (ã -> a).

   Abas: Codificar · Decodificar · Área do Mestre · Histórico
   Codificar e Área do Mestre compartilham o texto ao trocar de aba.

   Mapa do arquivo (procure pelos títulos "// ----"):
     1. Abas ................ troca de aba + texto compartilhado
     2. Cifra ............... reverseText, toGlyphs, fromGlyphs
     3. Codificar ........... quebra de linha, animação de tinta, render
     4. Decodificar / Mestre  render de cada aba
     5. Caixas de texto ..... autoGrow, botão ×, contador de caracteres
     6. Inverter ............ ordem das palavras / letras das palavras
     7. Copiar / imagem / .txt / baixar a fonte
     8. Histórico ........... localStorage (COD / DEC / MES)
     9. Atalhos, modo apresentação, partículas

   Regras que evitam bugs antigos (não desfazer):
     - o medidor de largura fica DENTRO do container real (getLineMeasurer)
     - medir com scrollWidth, nunca getBoundingClientRect().width
     - a caixa da Decodificar é UMA textarea com direction:rtl (sem espelho)
   ===================================================================== */

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

// ---- tab switching (Codificar / Decodificar / Área do Mestre / Histórico) ----
const btnEncode = document.getElementById("btnEncode");
const btnDecode = document.getElementById("btnDecode");
const btnMaster = document.getElementById("btnMaster");
const btnHistory = document.getElementById("btnHistory");
const panelEncode = document.getElementById("panelEncode");
const panelDecode = document.getElementById("panelDecode");
const panelMaster = document.getElementById("panelMaster");
const panelHistory = document.getElementById("panelHistory");

const TAB_PAIRS = [
  [btnEncode, panelEncode],
  [btnDecode, panelDecode],
  [btnMaster, panelMaster],
  [btnHistory, panelHistory],
];
function activateTab(btn){
  const prevBtn = (TAB_PAIRS.find(([b]) => b.classList.contains("active")) || [])[0];
  TAB_PAIRS.forEach(([b, p]) => {
    const active = b === btn;
    b.classList.toggle("active", active);
    b.setAttribute("aria-selected", String(active));
    p.classList.toggle("active", active);
  });
  // Re-measure line-wrapping the moment this tab becomes visible again,
  // rather than leaving whatever was last (possibly incorrectly) computed
  // while it sat hidden — closes the door on any stale-measurement bug
  // instead of just waiting for the user to notice and retype something.
  // Codificar and Área do Mestre work on the same source text: moving
  // between them carries over whatever was typed (if there is any). The
  // "input" event re-renders the destination, so it isn't rendered twice.
  let synced = false;
  const pair = (prevBtn === btnEncode && btn === btnMaster) || (prevBtn === btnMaster && btn === btnEncode);
  if(pair){
    const src = document.getElementById(prevBtn === btnEncode ? "inputEncode" : "inputMaster");
    const dst = document.getElementById(btn === btnEncode ? "inputEncode" : "inputMaster");
    if(src.value.trim() && src.value !== dst.value){
      dst.value = src.value;
      dst.dispatchEvent(new Event("input", { bubbles: true }));
      synced = true;
    }
  }
  if(!synced){
    if(btn === btnEncode) renderEncode();
    else if(btn === btnMaster) renderMaster();
  }
}
TAB_PAIRS.forEach(([b]) => b.addEventListener("click", () => activateTab(b)));
document.getElementById("tabs").addEventListener("keydown", (e) => {
  if(!["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key)) return;
  const buttons = TAB_PAIRS.map(([b]) => b);
  const i = buttons.indexOf(document.activeElement);
  if(i === -1) return;
  e.preventDefault();
  let next;
  if(e.key === "Home") next = 0;
  else if(e.key === "End") next = buttons.length - 1;
  else if(e.key === "ArrowRight") next = (i + 1) % buttons.length;
  else next = (i - 1 + buttons.length) % buttons.length;
  buttons[next].focus();
  activateTab(buttons[next]);
});

// Coalesces bursts of "input" events (fast typing, IME composition, huge
// pastes) into at most one re-render per animation frame.
function rafThrottle(fn){
  let scheduled = false;
  return function(...args){
    if(scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => { scheduled = false; fn.apply(this, args); });
  };
}

function playInk(el){
  el.classList.remove("ink-in");
  void el.offsetWidth;
  el.classList.add("ink-in");
}
// Reveals text one character at a time, like it's being freshly inked,
// instead of the whole line fading in at once. For very long pasted text,
// building hundreds of individually-animated spans would just be slow for
// no visual benefit, so it falls back to a single soft fade instead.
// The reveal order follows the site's own reading direction: within each
// line it starts from the *right* (where the first word you typed sits)
// and moves left, and line 1 finishes before line 2 starts — matching how
// the text is actually meant to be read, instead of a plain left-to-right
// sweep that would ink in the LAST word first.
const INK_CHAR_LIMIT = 400;
function animateReveal(el, text){
  el.innerHTML = "";
  if(text.length > INK_CHAR_LIMIT){
    el.textContent = text;
    playInk(el);
    return;
  }
  const step = 14, maxDelayPerLine = 560, lineStagger = 260;
  const lines = text.split("\n");
  lines.forEach((line, li) => {
    const chars = [...line];
    const lineStart = li * lineStagger;
    chars.forEach((ch, i) => {
      const distanceFromRight = chars.length - 1 - i;
      const span = document.createElement("span");
      span.className = "ink-char";
      span.textContent = ch;
      span.style.animationDelay = (lineStart + Math.min(distanceFromRight * step, maxDelayPerLine)) + "ms";
      el.appendChild(span);
    });
    if(li < lines.length - 1) el.appendChild(document.createElement("br"));
  });
}

function reverseText(text){
  // Reverse the letters within each word, but keep word order and
  // whitespace exactly as typed — so the first word you write stays
  // first (and on top when the line wraps), and copying matches
  // exactly what's shown on screen.
  return text.split(/(\s+)/).map(chunk => {
    if(/^\s+$/.test(chunk)) return chunk;
    return chunk.split("").reverse().join("");
  }).join("");
}

// ---- private-use-area glyph mapping ----
// A-Z/a-z map to U+E000..U+E019, which the embedded Cronicas font also maps
// to the same glyphs. This way, copied text isn't readable as scrambled
// Latin letters outside the site (it needs the font either way), while still
// being real, selectable, searchable text.
const PUA_BASE = 0xE000;
// The font only has plain A-Z, so an accented letter (ã, é, ç...) has no
// symbol of its own — it fell through untranslated before. Stripping the
// accent first means it just borrows its base letter's symbol instead.
function stripAccents(text){
  return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}
function toGlyphs(text){
  return stripAccents(text).replace(/[a-zA-Z]/g, ch => {
    const idx = ch.toLowerCase().charCodeAt(0) - 97;
    return String.fromCodePoint(PUA_BASE + idx);
  });
}
function fromGlyphs(text){
  let out = "";
  for(const ch of text){
    const cp = ch.codePointAt(0);
    if(cp >= PUA_BASE && cp <= PUA_BASE + 25){
      out += String.fromCharCode(97 + (cp - PUA_BASE));
    } else {
      out += ch;
    }
  }
  return out;
}

// ---- encode: line wrapping ----
// The browser's own bidi engine (CSS direction:rtl) only reorders words
// correctly when everything fits on one line. As soon as text wraps onto
// multiple lines, the browser decides the wrapping in logical (typed)
// order but then reorders words visually per paragraph, not per line —
// so a word can jump to the wrong line entirely. To fix this properly we
// compute the wrapping ourselves (measuring real rendered width) and then
// reverse the word order *within each line we just built*, so line order
// top-to-bottom always matches typing order, and each line reads right
// to left. Letters inside each word are already reversed by reverseText.
// The same wrapping algorithm is reused for the "Área do Mestre" panel too
// (plain letters instead of symbols), so it needs its own measurer keyed
// by which font/size actually applies — glyph-line (Cronicas) vs
// plain-line (EB Garamond) render at very different widths per character.
const lineMeasurers = {};
function getLineMeasurer(containerEl, className){
  if(!lineMeasurers[className]){
    const el = document.createElement("div");
    el.className = className;
    el.style.position = "absolute";
    el.style.visibility = "hidden";
    el.style.whiteSpace = "nowrap";
    el.style.pointerEvents = "none";
    el.style.left = "-99999px";
    el.style.top = "0";
    el.style.direction = "ltr";
    lineMeasurers[className] = el;
  }
  const measurer = lineMeasurers[className];
  // Reparent into the real output container (not a detached spot under
  // <body>) so it inherits whatever font-size actually applies there —
  // including the much bigger, !important override used in fullscreen /
  // "presenting" mode. Measuring at the wrong (smaller) size makes the
  // line-wrap decision stale the moment the real text renders bigger than
  // what was measured, and the browser then re-wraps it on its own,
  // unpredictably, on top of our own inserted breaks.
  if(measurer.parentElement !== containerEl){
    containerEl.appendChild(measurer);
  }
  return measurer;
}
function wrapLinesForDisplay(text, containerEl, className){
  // A small safety margin, not the raw container width: two separate DOM
  // elements (this hidden measurer and the real, later-rendered line) can
  // disagree by a pixel or two — italic fonts especially can have a little
  // slanted overhang — so measuring right up against the exact edge risks
  // the browser's own overflow-wrap kicking in afterwards and breaking a
  // word in half. Wrapping one word earlier than strictly necessary avoids
  // ever landing that close to the edge.
  const maxWidth = containerEl.clientWidth - 12;
  const measurer = getLineMeasurer(containerEl, className);
  const outLines = [];
  const paragraphs = text.split("\n");
  for(const para of paragraphs){
    const words = para.split(/\s+/).filter(Boolean);
    if(words.length === 0){ outLines.push(""); continue; }
    let current = [];
    for(const word of words){
      const candidate = current.length ? current.join(" ") + " " + word : word;
      measurer.textContent = candidate;
      // scrollWidth (a plain layout metric, like clientWidth) is used
      // instead of getBoundingClientRect().width on purpose: the latter
      // reflects the element's *visually transformed* box, so if this runs
      // while an ancestor is mid-way through the tab-switch "unroll"
      // animation (a slight rotateX/scale), it can misreport the width —
      // sometimes badly enough that almost nothing seems to fit, splitting
      // every single word onto its own line. scrollWidth ignores transforms
      // entirely and always matches how maxWidth itself was measured.
      if(current.length && maxWidth > 0 && measurer.scrollWidth > maxWidth){
        outLines.push(current.reverse().join(" "));
        current = [word];
      } else {
        current.push(word);
      }
    }
    outLines.push(current.reverse().join(" "));
  }
  return outLines.join("\n");
}

// ---- encode ----
// Each fresh translation gets a slightly different parchment "age" —
// different tear line, stains, tint — so it never looks quite the same twice.
const PARCHMENT_AGE_CLASSES = ["age-2", "age-3", "age-4"];
function rollParchmentAge(wrapEl){
  if(!wrapEl) return;
  wrapEl.classList.remove(...PARCHMENT_AGE_CLASSES);
  if(Math.random() < 0.7){
    wrapEl.classList.add(PARCHMENT_AGE_CLASSES[Math.floor(Math.random()*PARCHMENT_AGE_CLASSES.length)]);
  }
}
let encodeWasEmpty = true;
let decodeWasEmpty = true;

function renderEncode(){
  const text = document.getElementById("inputEncode").value.trim();
  const output = document.getElementById("outputEncode");
  if(!text){
    output.innerHTML = '<p class="output-empty">O texto traduzido aparece aqui.</p>';
    encodeWasEmpty = true;
    return;
  }
  if(encodeWasEmpty) rollParchmentAge(output.closest(".output-wrap"));
  encodeWasEmpty = false;
  const glyphText = toGlyphs(reverseText(text));
  const line = document.createElement("div");
  line.className = "glyph-line";
  const wrapped = wrapLinesForDisplay(glyphText, output, "glyph-line");
  output.innerHTML = "";
  output.appendChild(line);
  animateReveal(line, wrapped);
}
document.getElementById("inputEncode").addEventListener("input", rafThrottle(renderEncode));

// Re-wrap whenever the output box's width actually changes (window resize,
// the "chave do alfabeto" side/below toggle, mobile rotation) and once the
// custom Cronicas font finishes loading (its glyphs may be wider/narrower
// than the fallback font used for the very first measurement).
let lastEncodeOutputWidth = null;
function maybeRerenderEncode(){
  const output = document.getElementById("outputEncode");
  if(!output) return;
  const w = output.clientWidth;
  if(w !== lastEncodeOutputWidth){
    lastEncodeOutputWidth = w;
    renderEncode();
  }
}
window.addEventListener("resize", maybeRerenderEncode);
if(window.ResizeObserver){
  new ResizeObserver(maybeRerenderEncode).observe(document.getElementById("outputEncode"));
}
if(document.fonts && document.fonts.ready){
  document.fonts.ready.then(() => { lastEncodeOutputWidth = null; maybeRerenderEncode(); });
}

// ---- decode ----
function renderDecode(){
  const text = document.getElementById("inputDecode").value.trim();
  const output = document.getElementById("outputDecode");
  if(!text){
    output.innerHTML = '<p class="output-empty">O texto decifrado aparece aqui.</p>';
    decodeWasEmpty = true;
    return;
  }
  if(decodeWasEmpty) rollParchmentAge(output.closest(".output-wrap"));
  decodeWasEmpty = false;
  const line = document.createElement("div");
  line.className = "plain-line";
  const decoded = fromGlyphs(text);
  output.innerHTML = "";
  output.appendChild(line);
  animateReveal(line, decoded);
}
document.getElementById("inputDecode").addEventListener("input", rafThrottle(renderDecode));

// ---- master (GM area): plain reversed text, no glyph symbols ----
// Same idea as encode's copyable value (toGlyphs(reverseText(text))):
// each word's letters reversed AND the words themselves in reverse order,
// as ONE continuous transform with no width-aware line wrapping — the
// right form for a single copy/paste value, not for on-screen display.
function reverseWordsAndLetters(text){
  return text.split("\n").map(para => {
    const words = para.split(/\s+/).filter(Boolean);
    if(words.length === 0) return "";
    return words.map(w => w.split("").reverse().join("")).reverse().join(" ");
  }).join("\n");
}
let masterWasEmpty = true;
function renderMaster(){
  const text = document.getElementById("inputMaster").value.trim();
  const output = document.getElementById("outputMaster");
  if(!text){
    output.innerHTML = '<p class="output-empty">O texto invertido aparece aqui.</p>';
    masterWasEmpty = true;
    return;
  }
  if(masterWasEmpty) rollParchmentAge(output.closest(".output-wrap"));
  masterWasEmpty = false;
  const line = document.createElement("div");
  line.className = "plain-line";
  // Same pipeline as the symbol output (reverse letters per word, keep
  // typed word order, THEN let the width-aware wrapper reverse word order
  // *within each real rendered line*) — just skipping the symbol mapping,
  // so line breaks land in the same correct places as in Codificar.
  const lettersReversed = reverseText(text);
  const wrapped = wrapLinesForDisplay(lettersReversed, output, "plain-line");
  output.innerHTML = "";
  output.appendChild(line);
  animateReveal(line, wrapped);
}
document.getElementById("inputMaster").addEventListener("input", rafThrottle(renderMaster));

// ---- auto-growing textareas (no manual resize handle needed) ----
function autoGrow(field){
  field.style.height = "auto";
  const capped = Math.min(field.scrollHeight, 420);
  field.style.height = capped + "px";
  field.style.overflowY = field.scrollHeight > 420 ? "auto" : "hidden";
}
const inputEncodeEl = document.getElementById("inputEncode");
inputEncodeEl.addEventListener("input", () => autoGrow(inputEncodeEl));
autoGrow(inputEncodeEl);

const inputDecodeEl = document.getElementById("inputDecode");
inputDecodeEl.addEventListener("input", () => autoGrow(inputDecodeEl));
autoGrow(inputDecodeEl);

const inputMasterEl = document.getElementById("inputMaster");
inputMasterEl.addEventListener("input", () => autoGrow(inputMasterEl));
autoGrow(inputMasterEl);

// ---- clear (×) buttons + character counters ----
function wireClearButton(clearBtnId, textareaId, countId, renderFn, onAfterChange){
  const btn = document.getElementById(clearBtnId);
  const field = document.getElementById(textareaId);
  const counter = document.getElementById(countId);
  function updateChrome(){
    const len = field.value.length;
    btn.classList.toggle("show", len > 0);
    if(counter){
      counter.textContent = len > 0 ? `${len} / ${field.maxLength}` : "";
      counter.classList.toggle("near-limit", field.maxLength - len < 200);
    }
  }
  field.addEventListener("input", updateChrome);
  btn.addEventListener("click", () => {
    field.value = "";
    updateChrome();
    renderFn();
    if(onAfterChange) onAfterChange();
    field.focus();
  });
  updateChrome();
}
wireClearButton("clearEncode", "inputEncode", "countEncode", renderEncode, () => autoGrow(inputEncodeEl));
wireClearButton("clearDecode", "inputDecode", "countDecode", renderDecode, () => autoGrow(inputDecodeEl));
wireClearButton("clearMaster", "inputMaster", "countMaster", renderMaster, () => autoGrow(inputMasterEl));


// ---- "inverter ordem das palavras" (Codificar / Decodificar) ----
// Rewrites the text in the box so the WORDS come in the opposite order
// ("Kelvin Theodoro Dantas" -> "Dantas Theodoro Kelvin"). The letters inside
// each word are left exactly as typed — the normal cipher rules (letters
// reversed per word, accents stripped, symbol mapping) then apply on top of
// the new order like for any other text. It's a one-shot edit of the box's
// value, with no hidden state, so clicking it again simply restores the
// original order. Line breaks stay where they are (each line is reversed
// on its own) and the original spacing between words is preserved.
function reverseWordOrder(text){
  return text.split("\n").map(line => {
    const chunks = line.split(/(\s+)/);          // words at even indexes, spacing at odd
    const slots = [];
    chunks.forEach((c, i) => { if(i % 2 === 0 && c !== "") slots.push(i); });
    const words = slots.map(i => chunks[i]).reverse();
    slots.forEach((i, n) => { chunks[i] = words[n]; });
    return chunks.join("");
  }).join("\n");
}
function wireFlipButton(btnId, textareaId, transform = reverseWordOrder){
  const btn = document.getElementById(btnId);
  const field = document.getElementById(textareaId);
  btn.addEventListener("click", () => {
    if(!field.value.trim()) return;
    field.value = transform(field.value);
    // Fire the normal "input" event so the output, the counter, the ×
    // button and the auto-grow all update exactly as if it had been typed.
    field.dispatchEvent(new Event("input", { bubbles: true }));
    btn.classList.add("flipped");
    setTimeout(() => btn.classList.remove("flipped"), 700);
  });
}
wireFlipButton("flipEncode", "inputEncode");
wireFlipButton("flipDecode", "inputDecode");
// "Inverter letras das palavras": Kelvin -> nivleK, word order untouched.
// Reuses reverseText as-is (letters reversed per word, spacing and line
// breaks kept), so it's the exact mirror of the button above; clicking
// twice restores the original text.
wireFlipButton("flipLettersEncode", "inputEncode", reverseText);
wireFlipButton("flipLettersDecode", "inputDecode", reverseText);

// ---- "Testar na Decodificar" ----
// Puts exactly what the Codificar copy button would copy (the symbols)
// into the Decodificar box, as if it had been pasted there.
document.getElementById("sendToDecode").addEventListener("click", () => {
  const text = document.getElementById("inputEncode").value.trim();
  if(!text) return;
  addHistoryEntry("encode", text);
  activateTab(btnDecode);
  const dec = document.getElementById("inputDecode");
  dec.value = toGlyphs(reverseText(text));
  dec.dispatchEvent(new Event("input", { bubbles: true }));
});

// ---- download the Cronicas font (read back from the embedded @font-face) ----
document.getElementById("downloadFont").addEventListener("click", (e) => {
  const btn = e.currentTarget;
  const label = btn.querySelector("span");
  const prev = label.textContent;
  const css = Array.from(document.querySelectorAll("style")).map(st => st.textContent).join("\n");
  const m = css.match(/url\(\s*["']?data:font\/ttf;base64,([A-Za-z0-9+\/=]+)/);
  if(m){
    const bin = atob(m[1]);
    const bytes = new Uint8Array(bin.length);
    for(let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const url = URL.createObjectURL(new Blob([bytes], { type: "font/ttf" }));
    const a = document.createElement("a");
    a.href = url; a.download = "Cronicas.ttf"; a.click();
    URL.revokeObjectURL(url);
    btn.classList.add("copied"); label.textContent = "Baixado!";
  } else {
    label.textContent = "Não foi possível";
  }
  setTimeout(() => { btn.classList.remove("copied"); label.textContent = prev; }, 1600);
});

// ---- copy buttons ----
// Falls back to the old execCommand trick when the async Clipboard API is
// missing or blocked (older browsers, some in-app webviews, non-HTTPS
// local files), so "Copiar" still works almost everywhere.
async function copyTextRobust(text){
  if(navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext !== false){
    try{ await navigator.clipboard.writeText(text); return true; }catch(e){ /* fall through */ }
  }
  try{
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.left = "-9999px";
    ta.style.top = "0";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return ok;
  }catch(e){
    return false;
  }
}
function wireCopy(btnId, getText){
  const btn = document.getElementById(btnId);
  btn.addEventListener("click", async () => {
    const text = getText();
    if(!text) return;
    const label = btn.querySelector("span");
    const prev = label.textContent;
    const ok = await copyTextRobust(text);
    btn.classList.add(ok ? "copied" : "copy-error");
    label.textContent = ok ? "Copiado!" : "Não copiou";
    setTimeout(() => {
      btn.classList.remove("copied", "copy-error");
      label.textContent = prev;
    }, 1600);
  });
}
wireCopy("copyDecode", () => {
  const text = document.getElementById("inputDecode").value.trim();
  if(text) addHistoryEntry("decode", text);
  return text ? fromGlyphs(text) : "";
});
wireCopy("copyMaster", () => {
  const text = document.getElementById("inputMaster").value.trim();
  if(text) addHistoryEntry("master", text);
  return text ? reverseWordsAndLetters(text) : "";
});

// ---- copy as image (for pasting where the Cronicas font isn't installed) ----
// Several hand-drawn variants of the torn edge and stains, matching the
// same "age" variety used for the on-screen parchment — so exported images
// don't all look like an identical stamped-out template.
const TEAR_VARIANTS = [
  {
    top: [[0,2],[3,0],[9,1.5],[15,0],[22,1.2],[29,0],[36,1.5],[44,0.3],[52,1.6],[60,0],[68,1.2],[76,0],[84,1.4],[92,0.2],[100,1.5]],
    bottom: [[100,98],[96,100],[89,98.4],[82,100],[74,98.6],[66,100],[58,98.3],[50,100],[42,98.5],[34,100],[26,98.7],[18,100],[10,98.4],[3,100],[0,98.2]],
  },
  {
    top: [[0,1],[4,0],[11,2],[18,0.3],[25,1.8],[33,0],[40,1.2],[48,0],[56,1.7],[64,0.4],[72,1.5],[80,0],[88,1.1],[95,0.3],[100,1.8]],
    bottom: [[100,97],[94,100],[87,98.2],[80,100],[71,98.6],[63,100],[55,98],[47,100],[39,98.4],[31,100],[23,98.6],[15,100],[8,98.2],[2,100],[0,98.6]],
  },
  {
    top: [[0,3],[5,0],[13,1.8],[20,0],[27,1.4],[35,0.2],[43,1.6],[51,0],[59,1.3],[67,0],[75,1.7],[83,0.3],[91,1.5],[100,0]],
    bottom: [[100,99],[92,100],[85,98.5],[77,100],[69,98.2],[61,100],[53,98.6],[45,100],[37,98.3],[29,100],[21,98.5],[13,100],[5,98.2],[0,100]],
  },
];
function tearClipPath(ctx, x0, y0, w, h, variant){
  const v = TEAR_VARIANTS[variant % TEAR_VARIANTS.length];
  ctx.beginPath();
  v.top.forEach(([px,py],i)=>{
    const X = x0 + w*px/100, Y = y0 + h*py/100;
    if(i===0) ctx.moveTo(X,Y); else ctx.lineTo(X,Y);
  });
  v.bottom.forEach(([px,py])=>{
    ctx.lineTo(x0 + w*px/100, y0 + h*py/100);
  });
  ctx.closePath();
}
// Foxing/water-stain blotches, one style per variant, echoing the on-screen
// .age-2/.age-3 look — purely decorative, drawn under the ruled lines.
function drawStains(ctx, x0, y0, w, h, variant){
  const blot = (cx, cy, r, color) => {
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
    g.addColorStop(0, color);
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x0, y0, w, h);
  };
  if(variant === 1){
    blot(x0 + w*0.82, y0 + h*0.18, Math.min(w,h)*0.28, "rgba(80,55,20,.16)");
  } else if(variant === 2){
    blot(x0 + w*0.1, y0 + h*0.85, Math.min(w,h)*0.24, "rgba(60,40,15,.2)");
    blot(x0 + w*0.92, y0 + h*0.3, Math.min(w,h)*0.15, "rgba(60,40,15,.14)");
  }
}

function makeGrainPattern(ctx){
  const n = document.createElement("canvas");
  n.width = 90; n.height = 90;
  const nctx = n.getContext("2d");
  const img = nctx.createImageData(90, 90);
  for(let i=0;i<img.data.length;i+=4){
    const v = Math.random() * 255;
    img.data[i] = img.data[i+1] = img.data[i+2] = v;
    img.data[i+3] = Math.random() * 26; // low alpha speckle
  }
  nctx.putImageData(img, 0, 0);
  return ctx.createPattern(n, "repeat");
}

function drawWaxSeal(ctx, cx, cy, r){
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-8 * Math.PI/180);

  // two small drips peeking from behind the main blob
  ctx.beginPath(); ctx.ellipse(-r*0.55, r*0.72, r*0.28, r*0.22, 0, 0, Math.PI*2); ctx.fillStyle = "#3a0d18"; ctx.fill();
  ctx.beginPath(); ctx.ellipse(r*0.35, r*0.8, r*0.2, r*0.16, 0, 0, Math.PI*2); ctx.fill();

  // main irregular blob
  ctx.beginPath();
  ctx.ellipse(0, 0, r, r*0.96, 0.15, 0, Math.PI*2);
  const g = ctx.createRadialGradient(-r*0.3,-r*0.32, r*0.1, 0,0, r*1.1);
  g.addColorStop(0, "#a4384d");
  g.addColorStop(0.35, "#7a1f31");
  g.addColorStop(0.65, "#591525");
  g.addColorStop(1, "#2a0810");
  ctx.fillStyle = g;
  ctx.fill();

  // rim highlight + shade for a pressed, glossy wax look
  ctx.save();
  ctx.clip();
  ctx.beginPath(); ctx.ellipse(-r*0.35,-r*0.4, r*0.9, r*0.55, 0.3, 0, Math.PI*2);
  ctx.fillStyle = "rgba(255,255,255,.16)"; ctx.fill();
  ctx.beginPath(); ctx.ellipse(r*0.4, r*0.45, r*0.95, r*0.6, 0.3, 0, Math.PI*2);
  ctx.fillStyle = "rgba(0,0,0,.28)"; ctx.fill();
  ctx.restore();

  // engraved emblem (four-point star), simulated with offset light/dark copies
  const starPath = () => {
    const p = new Path2D("M0 -9 L2.2 -2.4 L9 0 L2.2 2.2 L0 9 L-2.2 2.2 L-9 0 L-2.2 -2.4 Z");
    return p;
  };
  ctx.save();
  ctx.scale(r/13, r/13);
  ctx.translate(1.1, 1.1); ctx.fillStyle = "rgba(255,255,255,.22)"; ctx.fill(starPath());
  ctx.translate(-2.2, -2.2); ctx.fillStyle = "rgba(0,0,0,.55)"; ctx.fill(starPath());
  ctx.restore();

  ctx.restore();
}

async function textToImageBlob(glyphText){
  await document.fonts.load("54px Cronicas");
  await document.fonts.ready;

  const fontSize = 54;
  const paddingX = 50;
  const paddingY = 46;
  const lineHeight = fontSize * 1.55;
  const variant = Math.floor(Math.random() * TEAR_VARIANTS.length);

  const measureCanvas = document.createElement("canvas");
  const mctx = measureCanvas.getContext("2d");
  mctx.font = `${fontSize}px Cronicas, serif`;

  // Wrap into lines that fit a much wider max width than before — a typical
  // clue/sentence should now fit in one or two lines instead of five or
  // six — then reverse the word order within each line (same fix as the
  // on-screen preview) so the exported image reads right-to-left like the
  // rest of the site.
  const maxWidth = 1500;
  const words = glyphText.split(/\s+/).filter(Boolean);
  const lines = [];
  let current = [];
  for(const word of words){
    const candidate = current.length ? current.join(" ") + " " + word : word;
    if(current.length && mctx.measureText(candidate).width > maxWidth){
      lines.push(current.reverse().join(" "));
      current = [word];
    } else {
      current.push(word);
    }
  }
  if(current.length) lines.push(current.reverse().join(" "));

  let widest = 0;
  for(const l of lines) widest = Math.max(widest, mctx.measureText(l).width);

  const cardW = Math.ceil(widest + paddingX * 2);
  const cardH = Math.ceil(lines.length * lineHeight + paddingY * 2 + 14);
  const margin = 46; // room for drop shadow + wax seal spill
  const width = cardW + margin * 2;
  const height = cardH + margin * 2 + 16;

  const canvas = document.createElement("canvas");
  const scale = 2; // sharper export
  canvas.width = width * scale;
  canvas.height = height * scale;
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingQuality = "high";
  ctx.scale(scale, scale);

  // drop shadow, cast by the torn-paper silhouette
  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,.5)";
  ctx.shadowBlur = 22;
  ctx.shadowOffsetY = 10;
  tearClipPath(ctx, margin, margin, cardW, cardH, variant);
  ctx.fillStyle = "#ddd0aa";
  ctx.fill();
  ctx.restore();

  // clip to the torn shape and paint parchment inside it
  ctx.save();
  tearClipPath(ctx, margin, margin, cardW, cardH, variant);
  ctx.clip();

  const grad = ctx.createLinearGradient(margin, margin, margin + cardW, margin + cardH);
  grad.addColorStop(0, "#e9dfc0");
  grad.addColorStop(1, "#ddd0aa");
  ctx.fillStyle = grad;
  ctx.fillRect(margin, margin, cardW, cardH);

  const warm1 = ctx.createRadialGradient(
    margin + cardW*0.2, margin + cardH*0.15, 1,
    margin + cardW*0.2, margin + cardH*0.15, cardW*0.42
  );
  warm1.addColorStop(0, "rgba(120,100,60,.14)");
  warm1.addColorStop(1, "rgba(120,100,60,0)");
  ctx.fillStyle = warm1;
  ctx.fillRect(margin, margin, cardW, cardH);

  const warm2 = ctx.createRadialGradient(
    margin + cardW*0.85, margin + cardH*0.8, 1,
    margin + cardW*0.85, margin + cardH*0.8, cardW*0.38
  );
  warm2.addColorStop(0, "rgba(90,75,45,.16)");
  warm2.addColorStop(1, "rgba(90,75,45,0)");
  ctx.fillStyle = warm2;
  ctx.fillRect(margin, margin, cardW, cardH);

  // extra foxing/stain blotches — varies with the chosen tear variant, same
  // spirit as the on-screen parchment's randomized "age" look
  drawStains(ctx, margin, margin, cardW, cardH, variant);

  // faint ruled lines, like the on-page parchment
  ctx.strokeStyle = "rgba(0,0,0,.07)";
  ctx.lineWidth = 1;
  for(let y = margin + 27; y < margin + cardH; y += 27){
    ctx.beginPath(); ctx.moveTo(margin, y); ctx.lineTo(margin + cardW, y); ctx.stroke();
  }

  // paper grain
  ctx.fillStyle = makeGrainPattern(ctx);
  ctx.fillRect(margin, margin, cardW, cardH);

  // the glyph text itself, with a subtle letterpress/emboss feel: a soft
  // pale halo just behind-and-below, then the dark ink with a whisper of
  // its own drop shadow, instead of one flat, lifeless fill color
  ctx.font = `${fontSize}px Cronicas, serif`;
  ctx.textBaseline = "middle";
  ctx.textAlign = "right";
  lines.forEach((l, i) => {
    const x = margin + cardW - paddingX;
    const y = margin + paddingY + lineHeight * i + lineHeight / 2;
    ctx.fillStyle = "rgba(255,250,235,.55)";
    ctx.fillText(l, x + 0.8, y + 1.2);
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,.25)";
    ctx.shadowBlur = 1.5;
    ctx.shadowOffsetX = 0.5;
    ctx.shadowOffsetY = 1;
    ctx.fillStyle = "#241b0f";
    ctx.fillText(l, x, y);
    ctx.restore();
  });
  ctx.restore();

  // subtle inked edge around the torn silhouette
  ctx.save();
  tearClipPath(ctx, margin, margin, cardW, cardH, variant);
  ctx.strokeStyle = "rgba(40,30,15,.3)";
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();

  // wax seal, stamped over the bottom-left edge, sized to the card
  const sealR = Math.max(22, Math.min(34, cardW * 0.035));
  drawWaxSeal(ctx, margin + cardW*0.09, margin + cardH - 6, sealR);

  return new Promise(resolve => canvas.toBlob(resolve, "image/png"));
}

async function copyImageOrDownload(glyphText, btn){
  if(!glyphText) return;
  const label = btn.querySelector("span");
  const prev = label.textContent;
  try{
    const blob = await textToImageBlob(glyphText);
    if(navigator.clipboard && window.ClipboardItem){
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
      btn.classList.add("copied");
      label.textContent = "Copiado!";
    } else {
      throw new Error("clipboard image API unavailable");
    }
  } catch(e){
    // fallback: download the image instead
    try{
      const blob = await textToImageBlob(glyphText);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "simbolos.png";
      a.click();
      URL.revokeObjectURL(url);
      label.textContent = "Baixado!";
    } catch(e2){
      label.textContent = "Erro";
    }
  }
  setTimeout(() => { btn.classList.remove("copied"); label.textContent = prev; }, 1600);
}

document.getElementById("copyEncodeImg").addEventListener("click", (e) => {
  const text = document.getElementById("inputEncode").value.trim();
  if(!text) return;
  addHistoryEntry("encode", text);
  copyImageOrDownload(toGlyphs(reverseText(text)), e.currentTarget);
});

// ---- download as .txt ----
function downloadTextFile(filename, content){
  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
function flashDownloaded(btn){
  const label = btn.querySelector("span");
  const prev = label.textContent;
  btn.classList.add("copied");
  label.textContent = "Baixado!";
  setTimeout(() => { btn.classList.remove("copied"); label.textContent = prev; }, 1600);
}
document.getElementById("downloadEncodeTxt").addEventListener("click", (e) => {
  const text = document.getElementById("inputEncode").value.trim();
  if(!text) return;
  addHistoryEntry("encode", text);
  downloadTextFile("simbolos.txt", toGlyphs(reverseText(text)));
  flashDownloaded(e.currentTarget);
});
document.getElementById("downloadDecodeTxt").addEventListener("click", (e) => {
  const text = document.getElementById("inputDecode").value.trim();
  if(!text) return;
  addHistoryEntry("decode", text);
  downloadTextFile("texto-decifrado.txt", fromGlyphs(text));
  flashDownloaded(e.currentTarget);
});
document.getElementById("downloadMasterTxt").addEventListener("click", (e) => {
  const text = document.getElementById("inputMaster").value.trim();
  if(!text) return;
  addHistoryEntry("master", text);
  downloadTextFile("texto-invertido.txt", reverseWordsAndLetters(text));
  flashDownloaded(e.currentTarget);
});

// ---- key chart (shown inline in both encode and decode panels) ----
const KEY_CHARS = ALPHABET.split("");
const keyGridHTML = KEY_CHARS.map(ch => `
  <div class="keycell"><span class="sym">${toGlyphs(ch)}</span><span class="norm">${ch.toUpperCase()}</span></div>
`).join("");
document.getElementById("keyGridEncode").innerHTML = keyGridHTML;
document.getElementById("keyGridDecode").innerHTML = keyGridHTML;

// ---- history ----
const HISTORY_KEY = "cronicas_history_v1";
const HISTORY_LIMIT = 20;

function loadHistory(){
  try{ return JSON.parse(localStorage.getItem(HISTORY_KEY)) || []; }
  catch(e){ return []; }
}
function saveHistoryList(list){
  try{ localStorage.setItem(HISTORY_KEY, JSON.stringify(list)); }catch(e){}
}
function escapeHtml(s){
  return s.replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function addHistoryEntry(type, input){
  if(!input) return;
  let list = loadHistory();
  if(list.length && list[0].type === type && list[0].input === input) return; // skip consecutive dup
  list.unshift({ type, input, ts: Date.now() });
  if(list.length > HISTORY_LIMIT) list = list.slice(0, HISTORY_LIMIT);
  saveHistoryList(list);
  renderHistory();
}
function renderHistory(){
  const list = loadHistory();
  const container = document.getElementById("historyList");
  const count = document.getElementById("historyCount");
  count.textContent = list.length ? `(${list.length})` : "";
  if(!list.length){
    container.innerHTML = '<p class="history-empty">Suas últimas traduções aparecem aqui.</p>';
    return;
  }
  container.innerHTML = "";
  list.forEach((entry, i) => {
    const isEncode = entry.type === "encode";
    const isMaster = entry.type === "master";
    const plainPreview = (isEncode || isMaster) ? entry.input : fromGlyphs(entry.input);
    const glyphPreview = isMaster ? reverseWordsAndLetters(entry.input)
                       : isEncode ? toGlyphs(reverseText(entry.input)) : entry.input;
    const item = document.createElement("div");
    item.className = "history-item";
    item.innerHTML = `
      <span class="hi-tag">${isMaster ? "MES" : isEncode ? "COD" : "DEC"}</span>
      <span class="hi-main">
        <div class="hi-plain">${escapeHtml(plainPreview) || "&nbsp;"}</div>
        <div class="${isMaster ? "hi-master" : "hi-glyph"}">${escapeHtml(glyphPreview) || "&nbsp;"}</div>
      </span>
      <button type="button" class="hi-del" title="Remover" aria-label="Remover">×</button>
    `;
    item.addEventListener("click", (e) => {
      if(e.target.closest(".hi-del")) return;
      if(isMaster){
        btnMaster.click();
        document.getElementById("inputMaster").value = entry.input;
        renderMaster();
        autoGrow(inputMasterEl);
      } else if(isEncode){
        btnEncode.click();
        document.getElementById("inputEncode").value = entry.input;
        renderEncode();
        autoGrow(inputEncodeEl);
      } else {
        btnDecode.click();
        document.getElementById("inputDecode").value = entry.input;
        renderDecode();
        autoGrow(inputDecodeEl);
      }
    });
    item.querySelector(".hi-del").addEventListener("click", (e) => {
      e.stopPropagation();
      const l = loadHistory();
      l.splice(i, 1);
      saveHistoryList(l);
      renderHistory();
    });
    container.appendChild(item);
  });
}
// Blur saves the entry, except when focus is only moving to one of the
// "inverter" buttons (the text is about to change; the final version gets
// saved on the next blur instead of a half-edited one).
function saveOnBlur(type, id){
  document.getElementById(id).addEventListener("blur", (e) => {
    const to = e.relatedTarget;
    if(to && to.closest && to.closest(".input-tools")) return;
    addHistoryEntry(type, document.getElementById(id).value.trim());
  });
}
saveOnBlur("encode", "inputEncode");
saveOnBlur("decode", "inputDecode");
saveOnBlur("master", "inputMaster");
document.getElementById("historyClear").addEventListener("click", () => {
  saveHistoryList([]);
  renderHistory();
});
renderHistory();

// ---- keyboard shortcuts ----
// Ctrl/Cmd+Enter copies the result of whichever tab is open; Esc blurs the
// focused field (handy on mobile to dismiss the keyboard).
document.addEventListener("keydown", (e) => {
  const isSubmitCombo = (e.key === "Enter") && (e.ctrlKey || e.metaKey);
  if(isSubmitCombo){
    if(panelEncode.classList.contains("active")){
      e.preventDefault();
      document.getElementById("copyEncodeImg").click();
    } else if(panelDecode.classList.contains("active")){
      e.preventDefault();
      document.getElementById("copyDecode").click();
    } else if(panelMaster.classList.contains("active")){
      e.preventDefault();
      document.getElementById("copyMaster").click();
    }
    return;
  }
  if(e.key === "Escape" && document.activeElement && document.activeElement.blur){
    document.activeElement.blur();
  }
});

// ---- output tools: presentation (fullscreen) mode ----
// `.card` sets a CSS `perspective` (for the tab-switch unroll animation),
// which per spec makes it a containing block for `position:fixed`
// descendants — so a naive fixed overlay nested inside it would be trapped
// inside the card instead of covering the viewport. When we can't use the
// real Fullscreen API, we sidestep that by physically relocating the
// element to <body> while presenting, then restoring it afterwards.
function exitPresentingFallback(el){
  el.classList.remove("presenting");
  if(el._fsPlaceholder){
    el._fsPlaceholder.replaceWith(el);
    el._fsPlaceholder = null;
  }
}
function enterPresentingFallback(el){
  const placeholder = document.createComment("fs-placeholder");
  el.before(placeholder);
  el._fsPlaceholder = placeholder;
  document.body.appendChild(el);
  el.classList.add("presenting");
}
function toggleFullscreen(el){
  const isNativeFs = document.fullscreenElement || document.webkitFullscreenElement;
  if(el.classList.contains("presenting")){
    exitPresentingFallback(el);
    syncPresentButtonIcons();
    return;
  }
  try{
    if(!isNativeFs){
      const req = el.requestFullscreen || el.webkitRequestFullscreen;
      if(req){ req.call(el); return; }
    } else {
      const exit = document.exitFullscreen || document.webkitExitFullscreen;
      if(exit){ exit.call(document); return; }
    }
  }catch(e){ /* fall through to the manual fallback below */ }
  enterPresentingFallback(el);
  syncPresentButtonIcons();
}
document.querySelectorAll(".present-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    toggleFullscreen(document.getElementById(btn.dataset.presentTarget));
  });
});
// Keep each button's icon (expand/collapse) in sync with the real fullscreen
// state, however it changes — our own button, Esc, or the browser's own UI.
function syncPresentButtonIcons(){
  document.querySelectorAll(".present-btn").forEach(btn => {
    const target = document.getElementById(btn.dataset.presentTarget);
    const active = target.classList.contains("presenting") ||
      document.fullscreenElement === target || document.webkitFullscreenElement === target;
    btn.classList.toggle("is-active", active);
  });
}
document.addEventListener("fullscreenchange", syncPresentButtonIcons);
document.addEventListener("webkitfullscreenchange", syncPresentButtonIcons);
// Esc already exits real Fullscreen natively; also let it close our manual fallback.
document.addEventListener("keydown", (e) => {
  if(e.key === "Escape"){
    document.querySelectorAll(".output-outer.presenting").forEach(exitPresentingFallback);
    syncPresentButtonIcons();
  }
});

// ---- particles ----
const particleField = document.getElementById("particles");
const N = 16;
for(let i=0;i<N;i++){
  const p = document.createElement("div");
  p.className = "particle" + (i % 5 === 0 ? " ember" : "");
  const size = 2 + Math.random()*3;
  const left = Math.random()*100;
  const duration = 14 + Math.random()*14;
  const delay = Math.random()*-24;
  const driftX = (Math.random()*60-30) + "px";
  p.style.width = size+"px";
  p.style.height = size+"px";
  p.style.left = left+"vw";
  p.style.setProperty("--drift-x", driftX);
  p.style.animationDuration = duration+"s";
  p.style.animationDelay = delay+"s";
  particleField.appendChild(p);
}
